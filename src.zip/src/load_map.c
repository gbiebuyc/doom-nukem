/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   load_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gbiebuyc <gbiebuyc@student.s19.be>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/04/13 02:56:31 by gbiebuyc          #+#    #+#             */
/*   Updated: 2019/04/22 02:19:39 by gbiebuyc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "doom_nukem.h"

int		load_wall_structure(t_data *d, int f)
{
	int		i;
	int		j;
	char	c;
	char	str[1000];

	i = 0;
	while (i < d->numwalls)
	{
		if (read(f, &d->walls[i], sizeof(t_wall)) == -1)
			return (ft_printf("failed to read wall structure\n"));
		j = 0;
		c = 0;
		while (c != '\0' || j == 0)
		{
			if (read(f, &c, 1) < 0)
				return (ft_printf("failed to get filename\n"));
			str[j] = c;
			j++;
		}
		d->walls[i].texture_name = ft_strdup(str);
		i++;
	}
	return (0);
}

void	load_map(t_data *d)
{
	int f;

	if (((f = open("map01", O_RDONLY)) == -1) ||
		// Load starting position
		read(f, &d->cam.pos, sizeof(t_vec3f)) == -1 ||
		read(f, &d->cam.rot, sizeof(double)) == -1 ||
		read(f, &d->cursectnum, sizeof(int16_t)) == -1 ||
		// Load all sectors
		read(f, &d->numsectors, sizeof(int16_t)) == -1 ||
		read(f, d->sectors, sizeof(t_sector) * d->numsectors) == -1 ||
		read(f, &d->numwalls, sizeof(int16_t)) == -1)
	///**/read(f, d->walls, sizeof(*d->walls) * d->numwalls) < 0)
		exit(ft_printf("map error\n"));
	else
	{
		if (load_wall_structure(d, f))
			exit (1);
		
	}
	close(f);
}
